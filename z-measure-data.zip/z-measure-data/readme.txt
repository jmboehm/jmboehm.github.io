Enforcement-intensity measures from:
J. Boehm, "The Impact of Contract Enforcement Costs on Value Chains and Aggregate Productivity", Review of Economics and Statistics, 2021

The files in this .zip archive contain the enforcement-intensity measures z^(1) and z^(2) measures in Stata 11 (z_measures.dta) and CSV (z_measures.csv) format. The file MyGTAPAgg.agg contains the definition of the industry codes as aggregation of the GTAP 8 industry codes.

You are free to use these data in your research, subject to proper attribution in the form of a citation of the associated research paper. 

Formal copyright information:

The data in this zip file (enforcement intensity measures) are (c) by Johannes Boehm.
It is licensed under a Creative Commons Attribution 4.0 International License (CC BY 4.0).

You should have received a copy of the license along with this
work.  If not, see <https://creativecommons.org/licenses/by/4.0/>.